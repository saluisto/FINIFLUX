/*
This is a small pre-processor code that comes with the main FINIFLUX-Matlab code. It writes all necessary PEST input files based on user specified
data. This code must be run prior to the main PEST optimization. 
Author: S. Frei (sven.frei@uni-bayreuth.de)
June 2015
*/

#include <iostream>
#include <fstream>
#include <string.h>
#include <sstream>
#include<windows.h>

using namespace std;

int main ()
{

int n_obs;
int ii;
int i;
int v_weight;
int nodes;
int hz;
int deg_k;
int dist;
stringstream *conv;
double *obs_points;
double *obs_conc;
double *river_width;
double *river_depth;
double *gw_concentration;
double *river_discharge;
double *depth_hz;
string PATH;
string num;
string *outfilename_pst;

ifstream infile;
ofstream outfile;

//read how many observations are avaiable
infile.open("n_observation.dat");
infile >> n_obs;
infile.close();

v_weight=1; //on off upstream weight

cout <<"Number of observations : "<< n_obs<<endl;

//array definition
obs_points=new double [n_obs];
obs_conc=new double [n_obs];
river_width=new double [n_obs-1];
river_depth=new double [n_obs-1];
gw_concentration=new double [n_obs-1];
river_discharge=new double [n_obs-1];
depth_hz=new double[n_obs-1];
	
SHELLEXECUTEINFO lpExecInfo ={0};
	lpExecInfo.cbSize = sizeof(SHELLEXECUTEINFO);
	lpExecInfo.lpFile = "struct.bat";
	lpExecInfo.lpVerb = "open";
	lpExecInfo.nShow = SW_SHOWNORMAL;
	lpExecInfo.fMask = SEE_MASK_NOCLOSEPROCESS;

//read in the working directory (avoid spaces in the path definition)
infile.open("path_definition.txt");
infile >> PATH;
//cout << PATH<<endl;
infile.close();


cout <<"OBSERVATION NODES INFORMATION :"<<endl;
cout <<"No."<<"\t\t""Position"<<"\t\t"<<"Concentration"<<endl;  
cout << endl;

//read in location of observation points
infile.open("observation_points.txt");

for (i=0;i<n_obs;i++)
{
	infile >> obs_points [i];
	//cout << i+1 <<"\t"<<obs_points[i] <<endl;
}
//cout << endl;

infile.close();

//read in observed Rn conentrations
infile.open("obs_concentrations.txt");

for (i=0;i<n_obs;i++)
{
	infile >> obs_conc [i];
	cout << i+1 <<"\t\t"<<obs_points[i] <<"\t\t"<<obs_conc [i]<<endl;
}

infile.close();

//read in number CPU's for parallel optimization 
infile.open("processor_nodes.txt");
infile >> nodes;
infile.close();

conv = new stringstream [nodes-1];
outfilename_pst = new string [nodes-1];

for (i=0;i<nodes-1;i++)
{
	conv[i] << i+1;
	conv[i] >> num;
	outfilename_pst[i] = "finiflux"+num+".pst";
}

cout << endl;
cout << "Number of FINITE ELEMENTS :"<< n_obs-1 <<endl;

//read in river depths for elements 
infile.open("river_depth.txt");
for (i=0;i<(n_obs-1);i++)
{
	infile >> river_depth [i];
}
infile.close();

//read in river widths for elements 
infile.open("river_width.txt");
for (i=0;i<(n_obs-1);i++)
{
	infile >> river_width [i];
}
infile.close();

//read in Rn groundwater concentrations
infile.open("gw_concentration.txt");
for (i=0;i<(n_obs-1);i++)
{
	infile >> gw_concentration [i];
}
infile.close();

//read in degasing option (1,2 or 3); 1 and 2 refer to empirical degasing models and 3 to user secified degasing rates
infile.open("k_degas.dat");
infile >> deg_k;
infile.close(); 

//write file containing known boubndary condition for the first node at X=0m
outfile.open("initial_c.dat");
outfile <<obs_conc [0]<<endl;
outfile.close();

//read in hyporheic zone option 0 without HZ 1 with HZ
infile.open("hz_on_off.dat");
infile >> hz;
infile.close();

//with HZ-option is used read in user specified depths for the hyporheic exchnage   
if (hz ==1)
{
	infile.open("depth_hz.dat");
	for (i=0;i<(n_obs-1);i++)
	{
		infile >> depth_hz [i];
	}
	infile.close();
}
else{}

//read in distribution model for HZ
infile.open("distribution.dat");
infile >> dist;
infile.close();




cout <<"------------------------------------------------------------------------------------------------------"<<endl;
cout <<"FINITE ELEMENT INFORMATION : see file FE_info.dat"<<endl;
cout <<"DEGASING OPTION: "<<deg_k<<endl;

outfile.open("FE_info.dat");

outfile <<"Element_No."<<"\t\t"<<"OBS_NODES"<<"\t\t"<<"RIVER_DEPTH"<<"\t\t"<<"RIVER_WIDTH"<<"\t\t"<<"GW_CONCENTRATION"<<"\t\t"<<"RIVER DISCHARGE"<<endl; 

//read in dischrage values for elements
infile.open("discharge.dat");
for (i=0;i<(n_obs-1);i++)
{
	infile >> river_discharge [i];
	outfile <<i+1<<"\t\t"<<i+1<<"-"<<i+2<<"\t\t"<<river_depth [i]<<"\t\t"<<river_width[i]<<"\t\t"<< gw_concentration [i]<<"\t\t"<<river_discharge [i]<<endl;
}
infile.close();
outfile.close();


cout <<"------------------------------------------------------------------------------------------------------"<<endl;
cout <<"WRITING PEST FILES"<<endl;

if(hz==1)
{
	cout <<"PARAMETER OPTIMIZATION FOR GW_INFLUX + HYPORHEIC ZONE PARAMETERS"<<endl;
	cout <<"PEST IS USING SINGULAR VALUE DECOMPOSITION"<<endl;
}
else
{
	cout <<"PARAMETER OPTIMIZATION FOR GW_INFLUX"<<endl;
}

cout <<"Writing Pest Control File : finiflux.pst"<<endl; 

//write PEST file finiflux.pst
outfile.open("finiflux.pst");

outfile <<"pcf"<<endl;
outfile <<"* control data"<<endl;
outfile <<"restart estimation"<<endl;
if(hz==1)
{
	outfile <<3*(n_obs-1)<<" "<<n_obs<<" "<<"3 0 1"<<endl;
	outfile <<"3 1 single point 1 0 0"<<endl;
	outfile <<"10.0 -2.0 0.15 0.01 10"<<endl;
}
else
{
	outfile <<n_obs-1<<" "<<n_obs<<" "<<"1 0 1"<<endl;
	outfile <<"1 1 single point 1 0 0"<<endl;
	outfile <<"1 2.0 0.3 0.01 5"<<endl;
}
outfile <<"5 5 0.001"<<endl;
outfile <<"0.1"<<endl;
outfile <<"100 0.01 4 3 0.01 3"<<endl;
outfile <<"1 1 1"<<endl;
//if HZ in enabled, PEST is using singular value decomposition (SVD)
if(hz==1)
{
	outfile <<"* singular value decomposition"<<endl;
	outfile <<"1"<<endl;
	outfile <<3*(n_obs-1)<<" 10.0E-6"<<endl;
	outfile <<"0"<<endl;
}
else {}
outfile <<"* parameter groups"<<endl;
if(hz==1)
{
	outfile <<"gw	relative	0.01	0.0	switch	2.0	parabolic"<<endl;
	outfile <<"th	relative	0.01	0.0	switch	2.0	parabolic"<<endl;
	outfile <<"h	relative	0.01	0.0	switch	2.0	parabolic"<<endl;
}
else
{
	outfile <<"gw	relative	0.01	0.0	switch	2.0	parabolic"<<endl;
}
outfile <<"* parameter data"<<endl;
if(hz==1)
{
	for (i=0;i<(n_obs-1);i++)
	{
		outfile <<"gw"<<i+1<<" log factor 0.00001 1.00E-09 10 gw 1 0 1"<<endl;
	}
	for (i=0;i<(n_obs-1);i++)
	{
		outfile <<"th"<<i+1<<" log factor 8640.0 1.0 86400000.0 th 1 0 1"<<endl;
	}
	for (i=0;i<(n_obs-1);i++)
	{
		outfile <<"h"<<i+1<<" none factor "<<depth_hz [i]<<" 0.001 2.0 h 1 0 1"<<endl;
	}
}
else
{
	for (i=0;i<(n_obs-1);i++)
	{
		outfile <<"gw"<<i+1<<" none factor 0.00001 1.00E-09 10 gw 1 0 1"<<endl;
	}
}
outfile <<"* observation groups"<<endl;
outfile <<"a"<<endl;
outfile <<"* observation data"<<endl;
for (i=0;i<(n_obs);i++)
{
	outfile <<"obs"<<i+1<<" "<<obs_conc [i]<<" 1 a"<<endl;
}
outfile <<"* model command line"<<endl;
outfile <<"run.bat "<<endl;
outfile <<"* model input/output"<<endl;
//if HZ is enabled additional PEST files are necessary
if(hz==1)
{
	outfile <<"GW_Flux.tpl "<<PATH<<"\\gw_inflow.dat"<<endl;
	outfile <<"rtimes_hz.tpl "<<PATH<<"\\rtimes_hz.dat"<<endl;
	outfile <<"depth_hz.tpl "<<PATH<<"\\depth_hz.dat"<<endl;
}
else
{
	outfile <<"GW_Flux.tpl "<<PATH<<"\\gw_inflow.dat"<<endl;
}
outfile <<"rn.ins "<<PATH<<"\\Rn_modeled.csv"<<endl;
outfile <<"* prior information"<<endl;
outfile.close();

//write PEST file "GW_Flux.tpl"
outfile.open("GW_Flux.tpl");

cout <<"Writing Pest Template File : GW_Flux.tpl"<<endl; 

outfile <<"ptf #"<<endl;
for (i=0;i<(n_obs-1);i++)
{
	outfile <<"#gw"<<i+1<<"#"<<endl;
}
outfile.close();

//additional PEST files in case HZ is enabled
if(hz==1)
{
	cout <<"Writing Pest Template File :rtimes_hz.tpl"<<endl; 
	outfile.open("rtimes_hz.tpl");
	outfile <<"ptf #"<<endl;
	for (i=0;i<(n_obs-1);i++)
		{
			outfile <<"#th"<<i+1<<"#"<<endl;
		}
	outfile.close();

	cout <<"Writing Pest Template File :rtimes_hz.tpl"<<endl; 
	outfile.open("depth_hz.tpl");
	outfile <<"ptf #"<<endl;
	for (i=0;i<(n_obs-1);i++)
		{
			outfile <<"#h"<<i+1<<"#"<<endl;
		}
	outfile.close();
}
else {}

//writing PEST file rn.ins 
outfile.open("rn.ins"),

cout <<"Writing Pest Instruction File : rs.ins"<<endl; 

outfile <<"pif @"<<endl;
for (i=0;i<(n_obs);i++)
{
	outfile <<"@"<<obs_points [i]<<"@ "<<"!obs"<<i+1<<"!"<<endl;
}
outfile.close();

cout <<endl;
cout <<"PEST will run on "<<nodes<<" cores, 1 master node and "<<nodes-1<< " slave nodes."<<endl;
cout <<endl;
cout <<"MASTER RUN DIRECTORY: "<<PATH<<endl;
cout << endl;
cout <<"SLAVE RUN DIRECTORIES: "<<endl;
for (i=0;i<nodes-1;i++)
{
	cout <<"SLAVE "<<i+1<<": "<<PATH<<"\\slave"<<i+1<<endl;
}
cout <<endl;
cout <<"------------------------------------------------------------------------------------------------------"<<endl;
cout <<"CREATING DIRECTORY STRUCTURE"<<endl;

//creating instruction file in all slaves


//write PEST file finiflux.pst

for (ii=0;ii<nodes-1;ii++)
{
	outfile.open(outfilename_pst[ii].c_str());

	outfile << "pcf" << endl;
	outfile << "* control data" << endl;
	outfile << "restart estimation" << endl;
	if (hz == 1)
	{
		outfile << 3 * (n_obs - 1) << " " << n_obs << " " << "3 0 1" << endl;
		outfile << "3 1 single point 1 0 0" << endl;
		outfile << "10.0 -2.0 0.15 0.01 10" << endl;
	}
	else
	{
		outfile << n_obs - 1 << " " << n_obs << " " << "1 0 1" << endl;
		outfile << "1 1 single point 1 0 0" << endl;
		outfile << "1 2.0 0.3 0.01 5" << endl;
	}
	outfile << "5 5 0.001" << endl;
	outfile << "0.1" << endl;
	outfile << "100 0.01 4 3 0.01 3" << endl;
	outfile << "1 1 1" << endl;
	//if HZ in enabled, PEST is using singular value decomposition (SVD)
	if (hz == 1)
	{
		outfile << "* singular value decomposition" << endl;
		outfile << "1" << endl;
		outfile << 3 * (n_obs - 1) << " 10.0E-6" << endl;
		outfile << "0" << endl;
	}
	else {}
	outfile << "* parameter groups" << endl;
	if (hz == 1)
	{
		outfile << "gw	relative	0.01	0.0	switch	2.0	parabolic" << endl;
		outfile << "th	relative	0.01	0.0	switch	2.0	parabolic" << endl;
		outfile << "h	relative	0.01	0.0	switch	2.0	parabolic" << endl;
	}
	else
	{
		outfile << "gw	relative	0.01	0.0	switch	2.0	parabolic" << endl;
	}
	outfile << "* parameter data" << endl;
	if (hz == 1)
	{
		for (i = 0; i < (n_obs - 1); i++)
		{
			outfile << "gw" << i + 1 << " log factor 0.00001 1.00E-09 10 gw 1 0 1" << endl;
		}
		for (i = 0; i < (n_obs - 1); i++)
		{
			outfile << "th" << i + 1 << " log factor 8640.0 1.0 86400000.0 th 1 0 1" << endl;
		}
		for (i = 0; i < (n_obs - 1); i++)
		{
			outfile << "h" << i + 1 << " none factor " << depth_hz[i] << " 0.001 2.0 h 1 0 1" << endl;
		}
	}
	else
	{
		for (i = 0; i < (n_obs - 1); i++)
		{
			outfile << "gw" << i + 1 << " none factor 0.00001 1.00E-09 10 gw 1 0 1" << endl;
		}
	}
	outfile << "* observation groups" << endl;
	outfile << "a" << endl;
	outfile << "* observation data" << endl;
	for (i = 0; i < (n_obs); i++)
	{
		outfile << "obs" << i + 1 << " " << obs_conc[i] << " 1 a" << endl;
	}
	outfile << "* model command line" << endl;
	outfile << "run.bat " << endl;
	outfile << "* model input/output" << endl;
	//if HZ is enabled additional PEST files are necessary
	if (hz == 1)
	{
		outfile << "GW_Flux.tpl " << PATH << "\\slave"<<  ii+1 <<"\\gw_inflow.dat" << endl;
		outfile << "rtimes_hz.tpl " << PATH << "\\slave"<<  ii+1 <<"\\rtimes_hz.dat" << endl;
		outfile << "depth_hz.tpl " << PATH << "\\slave"<<  ii+1 <<"\\depth_hz.dat" << endl;
	}
	else
	{
		outfile << "GW_Flux.tpl " << PATH << "\\slave"<<  ii+1 <<"\\gw_inflow.dat" << endl;
	}
	outfile << "rn.ins " << PATH <<"\\slave"<<  ii+1 <<"\\Rn_modeled.csv" << endl;
	outfile << "* prior information" << endl;
	outfile.close();

}


//batch file that is necessary to start the PEST optimization run.bat must be executed in all slave files after pslave.exe 
outfile.open("run.bat");
outfile <<"finiflux.exe"<<endl;
outfile.close();

// in order to copy all relevant files into the slave directories (parallel optimization), the code writes the batch files struct.bat and execute it 

outfile.open("struct.bat");
for (i=0;i<nodes-1;i++)
{
	
	outfile <<"mkdir slave"<<i+1<<endl;
	outfile <<"copy n_observation.dat "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy upstream_weight.dat "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy distribution.dat "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy observation_points.txt "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy river_width.txt "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy river_depth.txt "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy gw_inflow.dat "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy gw_concentration.txt "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy discharge.dat "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy run.bat "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy finiflux.exe "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy beopest64.exe "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy initial_c.dat "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy hz_on_off.dat "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy k_degas.dat "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy depth_hz.dat "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy porosity_hz.dat "<<PATH<<"\\slave"<<i+1<<endl;
	outfile <<"copy rtimes_hz.dat "<<PATH<<"\\slave"<<i+1<<endl;
	outfile << "copy inflow_conc.dat " << PATH << "\\slave" <<i+1<<endl;
	outfile << "copy inflow_length.dat " << PATH << "\\slave" <<i+1<<endl;
	outfile << "copy gamma_alpha.dat " << PATH << "\\slave" << i + 1 << endl;
	outfile << "copy river_inflow.dat " << PATH << "\\slave" << i + 1 << endl;
	outfile << "copy rn.ins " << PATH << "\\slave" << i + 1 << endl;
	outfile << "copy  GW_Flux.tpl " << PATH << "\\slave" << i + 1 << endl;
	outfile << "copy  finiflux"<<i+1<<".pst " << PATH << "\\slave" <<i+1<<"\\finiflux.pst"<< endl;
	outfile << "del  finiflux"<<i+1<<".pst" << endl;


	if (hz == 1)
	{
		outfile << "copy rtimes_hz.tpl " << PATH << "\\slave" <<i+1<< endl;
		outfile << "copy depth_hz.tpl " << PATH << "\\slave" <<i+1<< endl;
	}
	else {}

	if (deg_k==3)
	{
		outfile <<"copy k_values.dat "<<PATH<<"\\slave"<<i+1<<endl;
	}
	else {}

	if (dist == 3)
	{
		outfile << "copy gamma_alpha.dat " << PATH << "\\slave" << i + 1 << endl;
	}
	else {}

}

outfile.close();

ShellExecuteEx(&lpExecInfo);
WaitForSingleObject(lpExecInfo.hProcess, INFINITE);
cout <<endl;
cout <<"------------------------------------------------------------------------------------------------------"<<endl;
cout <<"PRE_PROCESSING FINISHED"<<endl;
cout <<"PEST IS READY TO START"<<endl;




return 0;
}